"""Portable private-count rerun; same fixed protocol and seeds as archived round3.
Extracted from run_closure_checks.py; functional interventions are not run here.
"""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from sklearn.metrics import f1_score
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'corrected_core_20261107'))
from generators import gen_ddxplus,gen_simsum_style
OUT=BASE/'results';OUT.mkdir(exist_ok=True)
def release(C,N,delta,eps,rng):
    Nn=np.maximum(N+rng.laplace(0,delta/eps,N.shape),1)
    Cn=np.clip(C+rng.laplace(0,delta/eps,C.shape),0,Nn[:,None])
    return Cn,Nn

def derived(C,N):
    pi=N/N.sum();p=(C+1)/(N[:,None]+2);m=pi@p
    complement=np.clip((m[None,:]-pi[:,None]*p)/(1-pi[:,None]),1e-12,1-1e-12)
    w1=np.log(p/complement);w0=np.log((1-p)/(1-complement))
    return pi,p,m,w1,w0

def predict(X,T):
    pi,p,m,w1,w0=T
    score=np.log(pi/(1-pi))[None,:]+X@w1.T+(1-X)@w0.T
    return score.argmax(1)

def main():
    data=[]
    xd,yd,_=gen_ddxplus(N=5000,K=100,D=49,max_S=20,seed=20260827);data.append(('DDXPlus',xd,yd,49))
    xs,ys,_=gen_simsum_style(N=10000,seed=20260907);data.append(('SimSUM',xs,ys,4))
    records=[];reconstruction=[]
    for name,raw,y,nclass in data:
        # Fixed public transform; do not fit quantiles or derive a data-dependent sensitivity.
        X=(raw>0).astype(float);nfeat=X.shape[1];delta=nfeat+1
        idx=np.random.default_rng(20261104).permutation(len(y));tr,te=idx[:int(.8*len(y))],idx[int(.8*len(y)):]
        N=np.bincount(y[tr],minlength=nclass).astype(float)
        C=np.array([X[tr][y[tr]==c].sum(0) for c in range(nclass)])
        ref=np.array([X[y==c].mean(0) for c in range(nclass)])
        clean=derived(C,np.maximum(N,1))
        def record(arm,eps,seed,T):
            pi,p,m,w1,w0=T
            rec=np.exp(w1)*m[None,:]/(pi[:,None]*np.exp(w1)+(1-pi[:,None]))
            np.testing.assert_allclose(rec,p,atol=1e-12)
            records.append({'dataset':name,'arm':arm,'epsilon':eps,'seed':seed,'n_train':len(tr),'n_test':len(te),
                'features':nfeat,'classes':nclass,'delta1_public_bound':delta,'audit_maxae':float(np.abs(p-ref).max()),
                'macro_f1':f1_score(y[te],predict(X[te],T),average='macro',zero_division=0),'roundtrip_maxae':float(np.abs(rec-p).max())})
        record('clean','clean',-1,clean)
        for eps in [.5,1,2,5,10,20,50]:
            for seed in range(20):
                Cn,Nn=release(C,N,delta,eps,np.random.default_rng(930000+seed));T=derived(Cn,Nn)
                record('joint_count_release',eps,seed,T)
                # Same noisy predictive function, exact audit summaries: no joint-DP claim.
                pi,p,m,w1,w0=T
                private_metrics=records[-1]
                records.append({**private_metrics,'arm':'predictor_only_clean_audit','audit_maxae':float(abs(clean[1]-ref).max()),'roundtrip_maxae':0.})
        print(name,'DP rerun complete, public sensitivity',delta,flush=True)
    df=pd.DataFrame(records);df.to_csv(OUT/'dp_public_bound_perseed.csv',index=False)
    df.groupby(['dataset','arm','epsilon'],sort=False)[['audit_maxae','macro_f1','roundtrip_maxae']].agg(['mean','std']).to_csv(OUT/'dp_public_bound_summary.csv')
    (OUT/'new_checks_protocol.json').write_text((BASE/'reference/new_checks_protocol.json').read_text(encoding='utf-8'),encoding='utf-8')
    print('COMPLETE',len(df),'private-count outcome rows')

if __name__=='__main__':main()

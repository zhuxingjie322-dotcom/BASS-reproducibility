from pathlib import Path
import sys,json,time,platform
import numpy as np,pandas as pd
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B/'corrected_core_20261107'))
from run import gen_ddxplus,binning,counts,probs,encode,decode
from sklearn.model_selection import train_test_split
O=B/'targeted_diagnostics_20261107';O.mkdir(exist_ok=True)
# Classical finite linear-query coverage: executable certificate and ambiguity witness.
states=np.array(list(np.ndindex(2,2,2)))
A=np.vstack([(states[:,:2]==z).all(1) for z in np.ndindex(2,2)]+[states[:,2]==z for z in range(2)]).astype(float)
M=np.vstack([np.ones(8),A]);q=(states[:,0]==1).astype(float);outside=((states[:,0]==1)&(states[:,2]==1)).astype(float)
coef=np.linalg.lstsq(M.T,q,rcond=None)[0];res=outside-M.T@np.linalg.lstsq(M.T,outside,rcond=None)[0]
h=res/np.max(np.abs(res));p0=np.ones(8)/8;eps=.1;pp=p0+eps*h;pm=p0-eps*h
assert min(pp.min(),pm.min())>0 and np.allclose(A@pp,A@pm) and abs(outside@pp-outside@pm)>.1
eta=.01;noise=np.linspace(-eta,eta,A.shape[0]);estimated=coef[0]+coef[1:]@(A@pp+noise);bound=np.linalg.norm(coef[1:],1)*eta
assert abs(estimated-q@pp)<=bound+1e-12
certificate={'states':states.tolist(),'retained_query_matrix':A.tolist(),'supported_query':q.tolist(),'coefficients_constant_then_retained':coef.tolist(),'coefficient_residual':float(np.max(np.abs(M.T@coef-q))),'unsupported_joint_query':outside.tolist(),'indistinguishable_positive_distributions':[pp.tolist(),pm.tolist()],'retained_difference':float(np.max(np.abs(A@pp-A@pm))),'unsupported_target_values':[float(outside@pp),float(outside@pm)],'eta':eta,'observed_supported_query_error':float(abs(estimated-q@pp)),'certificate_error_bound':float(bound),'scope':'finite 3-binary-variable illustration, classical row-space criterion; no dense high-dimensional algorithm or novelty claim'}
(O/'coverage_certificate.json').write_text(json.dumps(certificate,indent=2),encoding='utf-8')
# Prespecified auxiliary synthetic scale grid, not a clinical generalization benchmark.
rows=[]
for K in [100,500,1000]:
 for seed in range(3):
  X,y,_=gen_ddxplus(N=5000,K=K,D=49,max_S=20,seed=20260827+seed)
  tr,te=train_test_split(np.arange(len(y)),test_size=.2,random_state=seed,stratify=y)
  tic=time.perf_counter();xt,xv,sizes,cuts=binning(X[tr],X[te]);pre=time.perf_counter()-tic
  groups={str(i):list(range(i,min(i+3,K))) for i in range(0,K,3)}
  tic=time.perf_counter();nd,tabs,blocks=counts(xt,y[tr],49,sizes,groups);pi=nd/nd.sum();q=probs(nd,tabs,1);bq=probs(nd,list(blocks.values()),1)
  artifact={'sizes':sizes,'cuts':cuts,'groups':groups,'prior':pi.tolist(),'marginals':[encode(z,pi) for z in q],'blocks':[encode(z,pi) for z in bq]};build=time.perf_counter()-tic
  raw=json.dumps(artifact,separators=(',',':')).encode();a=json.loads(raw);p=np.array(a['prior'])
  tic=time.perf_counter()
  for _ in range(20):mq=[decode(z,p) for z in a['marginals']];mb=[decode(z,p) for z in a['blocks']]
  query=(time.perf_counter()-tic)/20
  error=max(np.max(np.abs(z-r)) for z,r in zip(q+bq,mq+mb));assert error<1e-10
  # Matched direct tables provide the same declared targets and predictor inputs.
  direct={'sizes':sizes,'cuts':cuts,'groups':groups,'prior':pi.tolist(),'marginals':[z.tolist() for z in q],'blocks':[z.tolist() for z in bq]}
  rows.append(dict(features=K,seed=seed,n=5000,classes=49,blocks=len(groups),preprocess_s=pre,count_and_encode_s=build,all_target_query_ms=query*1000,bass_json_bytes=len(raw),direct_json_bytes=len(json.dumps(direct,separators=(',',':')).encode()),roundtrip=error,positive_feature_count_mean=float(X.sum(1).mean())))
  print(K,seed,'PASS',flush=True)
d=pd.DataFrame(rows);d.to_csv(O/'scaling_perseed.csv',index=False)
d.groupby('features').agg({k:['mean','std'] for k in ['preprocess_s','count_and_encode_s','all_target_query_ms','bass_json_bytes','direct_json_bytes','positive_feature_count_mean']}).to_csv(O/'scaling_summary.csv')
(O/'protocol.json').write_text(json.dumps({'grid_features':[100,500,1000],'seeds':[0,1,2],'generator_seeds':[20260827,20260828,20260829],'n':5000,'classes':49,'max_positive_features':20,'blocks':'contiguous triples, final remainder','hardware':platform.platform(),'timing':'single build per seed; query20 repetitions; no warm-up excluded, decode all marginal/block tables; generation, serialization, parsing excluded from query; preprocess separate','interpretation':'increasing K also changes background sparsity and signal proportion under fixed maxS, so scale grid is not a pure predictive robustness or utility comparison','scope':'synthetic scale diagnostic; no clinical high-dimensional benchmark, no matched vectorized baseline latency claim'},indent=2),encoding='utf-8')
print(d.groupby('features')[['count_and_encode_s','all_target_query_ms','bass_json_bytes','direct_json_bytes']].mean().to_string())

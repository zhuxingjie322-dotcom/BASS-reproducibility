from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
P=ROOT/'results'
d=pd.read_csv(P/'perseed.csv')
names=['DDXPlus','SimSUM','Heart','Breast']
methods=['BASS-coherent','Direct-Dirichlet-NB','Direct-MLE-NB','RF-inversion']
labels=['BASS','Count-NB','MLE-NB','RF inversion']
plt.rcParams.update({'font.size':14})
fig,axes=plt.subplots(1,2,figsize=(6.7,3.8))
for j,(method,label,color) in enumerate(zip(methods,labels,['#2166ac','#67a9cf','#b2182b','#666666'])):
 for ax,key in zip(axes,['macro_f1','maxae']):
  sub=d[(d.method==method)&(d.target=='marginal')].groupby('dataset')[key].agg(['mean','std']).loc[names]
  ax.errorbar(np.arange(4)+(j-1.5)*.13,sub['mean'],yerr=sub['std'],fmt=['o','s','^','D'][j],label=label,color=color,capsize=2,markersize=4)
for ax in axes:
 ax.set_xticks(range(4));ax.set_xticklabels(names,rotation=30,ha='right',fontsize=12);ax.grid(alpha=.2)
axes[0].set_ylabel('Macro-F1');axes[1].set_ylabel('Held-out marginal MaxAE')
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=2,fontsize=12,frameon=False)
fig.tight_layout(rect=[0,.22,1,1]);fig.savefig(P/'fig_pred_audit_corrected.pdf')

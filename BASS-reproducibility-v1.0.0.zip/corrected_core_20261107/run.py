"""Corrected inductive, coherent-count protocol; no historical outputs overwritten."""
from pathlib import Path
import json,hashlib,sys,platform
import numpy as np
import pandas as pd
import scipy
from scipy.special import softmax
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import CategoricalNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
import sklearn
from generators import gen_ddxplus,gen_simsum_style
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def datasets():
 x,y,_=gen_ddxplus();yield 'DDXPlus',x,y,{str(i):list(range(i,min(i+3,x.shape[1]))) for i in range(0,x.shape[1],3)}
 x,y,_=gen_simsum_style();yield 'SimSUM',x,y,{str(i):list(range(i,min(i+3,x.shape[1]))) for i in range(0,x.shape[1],3)}
 d=pd.read_csv(ROOT/'data/processed.cleveland.data',header=None,na_values='?').dropna();yield 'Heart',d.iloc[:,:-1].to_numpy(float),(d.iloc[:,-1]>0).to_numpy(int),{'stress':[7,8,9],'pain':[2,8]}
 d=pd.read_csv(ROOT/'data/wdbc.data',header=None);yield 'Breast',d.iloc[:,2:].to_numpy(float),(d[1]=='M').to_numpy(int),{'mean':[0,1,2],'se':[3,4,5],'worst':[20,21,22],'texture':[10,11,12]}
def binning(xtr,xte):
 cuts=[]
 for col in xtr.T:
  u=np.unique(col)
  v=(u[:-1]+u[1:])/2 if len(u)<=4 else np.unique(np.quantile(col,[.25,.5,.75]))
  cuts.append(v.tolist())
 transform=lambda x:np.column_stack([np.searchsorted(v,x[:,j],side='right') for j,v in enumerate(cuts)])
 return transform(xtr),transform(xte),[len(c)+1 for c in cuts],cuts
def counts(x,y,classes,sizes,groups):
 nd=np.bincount(y,minlength=classes).astype(float)
 tabs=[np.array([np.bincount(x[y==d,j],minlength=M) for d in range(classes)],float) for j,M in enumerate(sizes)]
 blocks={}
 for k,js in groups.items():
  code=np.ravel_multi_index(x[:,js].T,tuple(sizes[j] for j in js));M=int(np.prod([sizes[j] for j in js]))
  blocks[k]=np.array([np.bincount(code[y==d],minlength=M) for d in range(classes)],float)
 return nd,tabs,blocks
def probs(nd,tabs,a):return [(c+a)/(nd[:,None]+a*c.shape[1]) for c in tabs]
def encode(q,pi):
 m=pi@q;comp=(m[None,:]-pi[:,None]*q)/(1-pi[:,None])
 # All cells strictly positive at alpha=1; tiny cancellation is clipped numerically.
 w=np.log(q)-np.log(np.maximum(comp,1e-300))
 return {'marginal':m.tolist(),'woe':w.tolist()}
def decode(e,pi):
 w=np.array(e['woe']);m=np.array(e['marginal']);r=np.exp(w)
 return m[None,:]*r/(pi[:,None]*r+1-pi[:,None])
def predict(q,pi,x):
 score=np.tile(np.log(pi),(len(x),1))
 for j,p in enumerate(q):score+=np.log(np.maximum(p[:,x[:,j]].T,1e-300))
 return softmax(score,axis=1)
def metrics(q,ref,block=False):
 diff=np.concatenate([(p-r).ravel() for p,r in zip(q,ref)])
 kl=np.mean([np.sum(np.clip(r,1e-12,1)*np.log(np.clip(r,1e-12,1)/np.clip(p,1e-12,1)),axis=1).mean() for p,r in zip(q,ref)])
 return {'maxae':float(np.abs(diff).max()),'mae':float(np.abs(diff).mean()),'categorical_kl':float(kl)}
def main():
 rows=[];checks=[];splits=[]
 for name,x,y,groups in datasets():
  C=int(y.max()+1)
  for seed in range(10):
   tr,te=train_test_split(np.arange(len(y)),test_size=.2,random_state=seed,stratify=y)
   xt,xv,sizes,cuts=binning(x[tr],x[te]);yt,yv=y[tr],y[te]
   nd,ct,bt=counts(xt,yt,C,sizes,groups);nv,cv,bv=counts(xv,yv,C,sizes,groups);pi=nd/nd.sum()
   q=probs(nd,ct,1);bq=probs(nd,list(bt.values()),1)
   ref=probs(nv,cv,0);br=probs(nv,list(bv.values()),0)
   assert np.all(nd>0) and np.all(nv>0)
   artifact={'dataset':name,'seed':seed,'classes':list(range(C)),'sizes':sizes,'cuts':cuts,'groups':groups,'prior':pi.tolist(),'alpha':1,'marginals':[encode(z,pi) for z in q],'blocks':[encode(z,pi) for z in bq]}
   folder=OUT/'artifacts';folder.mkdir(exist_ok=True);path=folder/(name+'_'+str(seed)+'.json');path.write_text(json.dumps(artifact),encoding='utf-8')
   # Reload the released artifact; reconstruction and prediction read no records/counts.
   a=json.loads(path.read_text());ap=np.array(a['prior']);rq=[decode(t,ap) for t in a['marginals']];rb=[decode(t,ap) for t in a['blocks']]
   pred=predict(rq,ap,xv);direct=predict(q,pi,xv)
   nb=CategoricalNB(alpha=1,min_categories=sizes).fit(xt,yt);nbpred=nb.predict_proba(xv)
   for method,mq,mb,pr in [('BASS-coherent',rq,rb,pred),('Direct-Dirichlet-NB',q,bq,direct),('Direct-MLE-NB',probs(nd,ct,0),probs(nd,list(bt.values()),0),predict(probs(nd,ct,0),pi,xv))]:
    for target,est,r in [('marginal',mq,ref),('blocks',mb,br)]:rows.append(dict(dataset=name,seed=seed,method=method,target=target,macro_f1=f1_score(yv,pr.argmax(1),average='macro'),**metrics(est,r)))
   rf=RandomForestClassifier(n_estimators=100,n_jobs=2,random_state=seed).fit(xt,yt);rp=rf.predict_proba(xv)
   # Decision-only inversion uses held-out covariates; distinct access regime.
   inv=[np.array([(rp[:,d,None]*(xv[:,j,None]==np.arange(M))).sum(0)/rp[:,d].sum() for d in range(C)]) for j,M in enumerate(sizes)]
   rows.append(dict(dataset=name,seed=seed,method='RF-inversion',target='marginal',macro_f1=f1_score(yv,rp.argmax(1),average='macro'),**metrics(inv,ref)))
   # A coherent deletion updates every dependent statistic, then matches a refit.
   nd2,ct2,bt2=counts(xt[1:],yt[1:],C,sizes,groups);nddel=nd.copy();nddel[yt[0]]-=1
   cdel=[c.copy() for c in ct]
   for j,c in enumerate(cdel):c[yt[0],xt[0,j]]-=1
   uq=probs(nddel,cdel,1);fresh=probs(nd2,ct2,1)
   pred_after=predict(uq,nddel/nddel.sum(),xv)
   check=dict(dataset=name,seed=seed,roundtrip=max(np.max(np.abs(z-r)) for z,r in zip(q,rq)),block_roundtrip=max(np.max(np.abs(z-r)) for z,r in zip(bq,rb)),prediction_equal=np.max(np.abs(pred-direct)),sklearn_nb_equal=np.max(np.abs(pred-nbpred)),delete_refit=max(np.max(np.abs(z-r)) for z,r in zip(uq,fresh)),delete_prediction_change=np.max(np.abs(pred_after-pred)),max_normalization=max(np.max(np.abs(z.sum(1)-1)) for z in rq))
   assert max(check[k] for k in ['roundtrip','block_roundtrip','prediction_equal','sklearn_nb_equal','delete_refit','max_normalization'])<1e-10
   checks.append(check);splits.append(dict(dataset=name,seed=seed,train=tr.tolist(),test=te.tolist(),cuts=cuts,sizes=sizes))
   print(name,seed,'PASS',flush=True)
  pd.DataFrame(rows).to_csv(OUT/'perseed.csv',index=False);pd.DataFrame(checks).to_csv(OUT/'checks.csv',index=False)
 pd.DataFrame(rows).groupby(['dataset','method','target'])[['maxae','mae','categorical_kl','macro_f1']].agg(['mean','std']).to_csv(OUT/'summary.csv')
 (OUT/'splits.json').write_text(json.dumps(splits),encoding='utf-8')
 protocol={'version':'corrected-core-1','seeds':list(range(10)),'split':'stratified 80/20, before fitting transformations','preprocessing':'training-only quantiles or low-cardinality midpoint cutpoints; no heldout-fitted support','smoothing':'coherent categorical (count+1)/(Nclass+states)','reference':'independent held-out empirical conditionals, unsmoothed; not population truth','metric':'mean per-feature or per-block categorical KL(reference||estimate), clipped1e-12; not historical Bernoulli KL','classes':'declared benchmark domains; all train/test class counts asserted positive','prediction':'categorical naive Bayes; block tables are audit-only, not new predictive claims','paired_inference':'BASS and direct Dirichlet are algebraically identical; no nonsignificance-as-equivalence claim','versions':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__},'platform':platform.platform(),'files':{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'run.py',ROOT/'generators.py',*sorted((ROOT/'data').glob('*'))]}}
 (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
 print('COMPLETE',len(rows),'outcome rows',flush=True)
if __name__=='__main__':main()

# Corrected core

Run python run.py with root requirements. Four datasets and ten stratified splits use training-only preprocessing and normalized categorical smoothing. Saved references are in ../reference/core/, separate from generated results/.

The reference protocol.json records the original environment and hashes. Its original word "independent" means held out from training; repeated splits share a dataset. Numerical tolerances concern reconstruction and computational agreement, not population accuracy.

Block tables support audit queries, not additional marginal predictor factors. Deletion checks cover a known marginal contribution with fixed preprocessing, not general unlearning or block deletion.

Author code: MIT. UCI attribution and CC BY 4.0: ../DATA_LICENSE.md.

import numpy as np


def gen_ddxplus(N=5000, K=100, D=49, max_S=20, seed=20260827):
    """Synthetic differential-diagnosis dataset (sparse multi-class)."""
    rng = np.random.default_rng(seed)
    # near-uniform priors (mild heterogeneity), guaranteed min class count
    w_prior = np.ones(D) * 0.8 + rng.random(D) * 0.4
    priors = w_prior / w_prior.sum()
    y = rng.choice(D, size=N, p=priors)
    # guarantee every disease has >= 50 patients
    for d in range(D):
        if (y == d).sum() < 50:
            refill = rng.choice(N, size=50 - (y == d).sum(), replace=False)
            y[refill] = d
    bg = 0.02  # background feature probability
    # per-disease signature features
    sig_feats, sig_p = {}, {}
    for d in range(D):
        m = int(rng.integers(9, 13))
        f = rng.choice(K, size=m, replace=False)
        sig_feats[d] = f
        sig_p[d] = rng.uniform(0.55, 0.95, size=m)
    P = np.full((N, K), bg)
    for d in range(D):
        idx = np.where(y == d)[0]
        P[np.ix_(idx, sig_feats[d])] = sig_p[d]
    X = (rng.random((N, K)) < P).astype(np.float64)
    # truncate per-record sparsity at max_S (keeps Delta_1 bound valid)
    sums = X.sum(axis=1)
    over = np.where(sums > max_S)[0]
    for i in over:
        drop = rng.choice(np.where(X[i] > 0)[0], size=int(sums[i] - max_S), replace=False)
        X[i, drop] = 0
    X = X.astype(np.float64)
    S_max = int(X.sum(axis=1).max())
    return X, y, S_max

def gen_simsum_style(N=10000, seed=20260907):
    """SimSUM-style synthetic with known ground-truth P(X|Y)."""
    rng = np.random.default_rng(seed)
    d1 = rng.random(N) < 0.30
    d2 = rng.random(N) < 0.18
    y = d1.astype(int) * 2 + d2.astype(int)
    feats, names = [], []

    def add(name, p):
        feats.append((rng.random(N) < p).astype(float))
        names.append(name)

    add('sym_fever',   np.where(d1, 0.80, np.where(d2, 0.35, 0.10)))
    add('sym_cough',   np.where(d1, 0.70, np.where(d2, 0.45, 0.12)))
    add('sym_fatigue', np.where(d1 | d2, 0.65, 0.15))
    add('sym_pain',    np.where(d2, 0.75, 0.20))
    add('sym_nausea',  np.where(d1 & d2, 0.60, 0.18))
    for i, pv in enumerate([0.22, 0.18, 0.12, 0.09]):
        add('comorb_%d' % (i + 1), np.full(N, pv))
    for i, pv in enumerate([0.25, 0.15, 0.20]):
        add('ext_%d' % (i + 1), np.full(N, pv))
    add('treatment_1', np.where(d1 | d2, 0.55, 0.08))
    days = rng.integers(0, 15, size=N).astype(float)
    feats.append(days)
    names.append('days_at_home')
    X = np.column_stack(feats)
    return X, y, names

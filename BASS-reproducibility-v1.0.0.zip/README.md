# BASS: focused reproducibility archive

Version **1.0.0** accompanies *BASS: An Audit-Oriented Statistical Representation Framework for Distribution-Level Knowledge Auditing*.

This release covers the corrected core, fixed-public-bound private-count experiment, finite query certificate and synthetic scale diagnostics. Historical comparisons are separate and are not all refitted here.

## Quick start

Use Python 3.10 and the pinned dependencies:

    python -m pip install -r requirements.txt
    python verify_release.py
    python verify_release.py --rerun-core --rerun-private --rerun-scale

Verification first checks file hashes, then executes the selected protocols and checks outputs against separate references. No network download, original absolute repository, GPU or protected clinical dataset is required after dependencies are installed.

Individual entry points:

    python corrected_core_20261107/run.py
    python private_count/run.py
    python targeted_diagnostics_20261107.py

## Scope and paper mapping

| Component | Reference | Scope |
| --- | --- | --- |
| Corrected core | reference/core/ | Main Tables 1–2 and Figure 2; four datasets, ten stratified splits, 280 outcome and 40 check rows |
| Private counts | private_count/reference/ | Main Table 5 and Figure 3; 562 rows including clean and diagnostic arms |
| Linear queries | reference/diagnostics/coverage_certificate.json | Eight-state illustration of classical row-space support |
| Scale grid | reference/diagnostics/scaling_perseed.csv | Supplementary scale table; 100/500/1,000 features and three seeds |
| Block manifest | reference/corrected_core_block_manifest.json | 45 definitions and 450 split-specific records |

Indices and cutpoints are in reference/core/splits.json.gz. A core rerun writes uncompressed splits and all 40 artifacts under corrected_core_20261107/results/. One example artifact is supplied; the others are regenerated to keep the archive small.

## Redraw quantitative figures

    python -m pip install -r requirements-figures.txt
    python verify_release.py --restore-reference
    python corrected_core_20261107/plot_corrected.py
    python plot_private_count.py

Plots use archived means and sample SD; fonts/layout may differ by platform. Figure 1 is a conceptual schematic outside these quantitative experiments.

## Interpretation and limits

- The core uses training-only transforms and normalized categorical smoothing. RF inversion also reads held-out covariates. Reference errors, reconstruction residuals and prediction checks are distinct.
- Independent CategoricalNB is a computational control. BASS and matched Dirichlet counts agree by construction; no new-estimator superiority is claimed.
- Privacy uses public event definitions, a fixed training cohort and add/remove sensitivity K+1. Evaluation references and metrics do not automatically inherit DP.
- The scale grid is synthetic; hardware-dependent timing is not expected to match exactly.
- Historical dependence/KQ summaries (main Tables 3–4), all legacy broad-learner refits, clinical deployment validation and arbitrary deep-model knowledge recovery are **not** reproduced by this focused release. Do not pool these protocols or infer that every historical result has been independently refitted.

## Rights and citation

Author code/documentation: **MIT**, see LICENSE. Public UCI benchmarks: **CC BY 4.0**, see DATA_LICENSE.md. Synthetic cohorts are explicitly local style approximations.

CITATION.cff provides citation metadata. No Zenodo deposit or DOI is claimed.
